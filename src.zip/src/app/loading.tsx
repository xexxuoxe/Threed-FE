import FullPageLoading from '@lib/loading/full.component'

export default function Loading() {
  return (
    <FullPageLoading></FullPageLoading>
  )
}