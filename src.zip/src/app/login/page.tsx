import LoginComponent from "@components/page/login/login.component";

export default function LoginPage() {
  return <LoginComponent />;
}
