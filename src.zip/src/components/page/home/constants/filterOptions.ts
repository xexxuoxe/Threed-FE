export const skillOptions = ['JAVA', 'SPRING', 'NEXT.JS', 'REACT', 'JAVASCRIPT', 'NODE.JS', 'TYPESCRIPT', '기타'];
export const fieldOptions = ['AI', 'Back', 'Front', 'Dev Ops', 'DB', 'Mobile', 'Collab Tool', '기타'];
