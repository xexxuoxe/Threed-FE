// import {useState} from "react";

// const [selectedSkill, setSelectedSkill] = useState<string[]>([]);
// const [selectedField, setSelectedField] = useState<string[]>([]);

